

import java.util.ArrayList;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ZipCodeRanges;
import Range;

public class ZipCodeRangesTest {

	
	ArrayList<Range> mergedExpecteds;
	ArrayList<Range> mergedActuals;
	

	@Before
	public void before(){
		exec = new ZipCodeRanges();
		mergedExpecteds = new ArrayList<Range>();
		mergedExpecteds = exec.readInput(expected);
	}
	
	@Test
	public void testCase() {
		mergedActuals = new ArrayList<Range>();
		mergedActuals = exec.executeMe(input, actual);
		for (int i = 0; i < mergedActuals.size(); i++) {
			Assert.assertEquals(mergedExpecteds.get(i).toString(), mergedActuals.get(i).toString());
		}
	}
	
	@After
	public void after() {
		exec = null;
		expected = null;
	}
}

