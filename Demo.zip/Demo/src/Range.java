
public class Range {
  private int upperBound;
  private int lowerBound;


  public Range(int lowerBound, int upperBound) {
    if (lowerBound <= upperBound) {
  
      this.lowerBound = lowerBound;
      this.upperBound = upperBound;
    } else {
      this.lowerBound = upperBound;
      this.upperBound = lowerBound;
    }
  }


  public int getLowerBound() {
    return this.lowerBound;
  }


  public int getUpperBound() {
    return this.upperBound;
  }

  
  public void setLowerBound(int lowerBound) {
    this.lowerBound = lowerBound;
  }


  public void setUpperBound(int upperBound) {
    this.upperBound = upperBound;
  }


  public String formatString() {
    return String.format("[%d,%d]", this.lowerBound, this.upperBound);
  }
}