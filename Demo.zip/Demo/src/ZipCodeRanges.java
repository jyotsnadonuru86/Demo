
import java.util.ArrayList;
import java.util.ListIterator;


public class ZipCodeRanges {
  
  private static ArrayList<Range> rangeList = new ArrayList<Range>();

 
  public static void generateMinimumRanges(Range range) {
    
    if (rangeList.size() == 0) {
    
      rangeList.add(range);
    } else {
     
      ListIterator<Range> rangeListIterator = rangeList.listIterator();

     
      boolean addToRangeList = true;

      
      while (rangeListIterator.hasNext()) {
       
        Range nextRange = rangeListIterator.next();

        
        if (range.getLowerBound() >= nextRange.getLowerBound() && range.getUpperBound() <= nextRange.getUpperBound()) {

          addToRangeList = false;
          
        } else if (range.getLowerBound() > nextRange.getUpperBound() || range.getUpperBound() < nextRange.getLowerBound()) {
         
          addToRangeList = true;
        
        } else if (range.getLowerBound() < nextRange.getLowerBound() && range.getUpperBound() > nextRange.getUpperBound()) {
   
          rangeListIterator.remove();

          addToRangeList = true;

        } else if (range.getLowerBound() < nextRange.getLowerBound() && range.getUpperBound() < nextRange.getUpperBound()) {
        
          range.setUpperBound(nextRange.getUpperBound());

          rangeListIterator.remove();

          addToRangeList = true;
       
        } else if (range.getLowerBound() > nextRange.getLowerBound() && range.getUpperBound() > nextRange.getUpperBound()) {
 
          range.setLowerBound(nextRange.getLowerBound());

          rangeListIterator.remove();

          addToRangeList = true;
        }
      }

      if (addToRangeList) {
        rangeList.add(range);
      }
    }
  }


  public static void printMinimumRanges() {
    if (rangeList.size() > 0) {
  
      for (Range range : rangeList) {
        System.out.println(range.formatString());
      }
    }
  }

  public static void main(String[] args) {
 
    Range rangeOne = new Range(94133, 94133);
    Range rangeTwo = new Range(94200, 94299);
    Range rangeThree = new Range(94226,94399);

    ZipCodeRanges.generateMinimumRanges(rangeOne);
    ZipCodeRanges.generateMinimumRanges(rangeTwo);
    ZipCodeRanges.generateMinimumRanges(rangeThree);


    ZipCodeRanges.printMinimumRanges();

   
  }
}